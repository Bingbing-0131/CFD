import matplotlib.pyplot as plt
import numpy as np
import glob
import os

# Set the folder where BTCS output files are stored
folder = "BTCS/sin/200_0.1"  # Change this if the results are in a different directory

# Define time step (dt) based on your simulation setup
dt = 2.5e-6  # Adjust this value according to your BTCS settings

# Define the time steps we want to plot
selected_times = [0.0, 0.1,0.2,0.3,0.4,0.5, 0.6,0.7,0.8,0.9,1.0]

# Get all result files
files = sorted(glob.glob(os.path.join(folder, "BTCS_step_*.txt")))

# Dictionary to store the data for selected time steps
data_dict = {}

# Process each file
for file in files:
    # Extract step number from filename
    step = int(file.split("_")[-1].split(".")[0])
    time = step * dt

    # Check if this time step is in our selected list
    if time in selected_times:
        # Load data from the file
        data = np.loadtxt(file)
        x = data[:, 0]  # Spatial coordinate
        u = data[:, 1]  # Solution u(x, t)
        print(u)

        # Store data
        data_dict[time] = (x, u)

# Plot results
plt.figure(figsize=(8, 6))

for time, (x, u) in sorted(data_dict.items()):
    print(time)
    plt.plot(x, u, label=f"t = {time:.5f}")

# Customize plot
plt.xlabel("x")
plt.ylabel("u(x, t)")
plt.legend()
plt.grid(True)
plt.savefig("fig/BTCS_sin_200_0.1.jpg")
# Show plot
plt.show()

