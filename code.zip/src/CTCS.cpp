#include "CTCS.h"

double CTCS::Initial_condition(double x)
{
    if (x > 0.0 && x < 0.3)
    {
        return 0.0;
    }
    else if (x >= 0.3 && x <= 0.6)
    {
        return 1.0;
    }
    else if (x > 0.6 && x < 1.0)
    {
        double f = 1 + 2.5 * (x - 0.6);
        return f;
    }
    else if (x == 0.0)
    {
        return 0.0;
    }
    else if (x == 1.0)
    {
        return 2.0;
    }
    else
    {
        std::cout << "Error: Out of Range";
        return 0;
    }
}

double CTCS::left_boundary(double t)
{
    return 0.0;
}

double CTCS::right_boundary(double t)
{
    return 2.0;
}

void CTCS::Initialize(int mx_, double gamma_, double sigma_, std::string folder_)
{
    mx = mx_;
    dx = 1.0 / mx;
    gamma = gamma_;
    sigma = sigma_;
    dt = sigma * dx * dx / gamma;

    u_prev.resize(mx);
    u_cur.resize(mx);
    u_new.resize(mx);
    for (int i = 0; i < mx; i++)
    {
        u_prev[i] = Initial_condition(i * dx);
        std::cout<<u_prev[i]<<std::endl;;
    }
    for (int i = 1; i < mx - 1; i++)
    {
        u_cur[i] = sigma * u_prev[i + 1] + (1 - 2 * sigma) * u_prev[i] + sigma * u_prev[i - 1];
        std::cout<<u_cur[i]<<std::endl;;
    }
    u_cur[0] = left_boundary(current_step * dt);
    u_cur[mx - 1] = right_boundary(current_step * dt);
    folder = folder_;
}

void CTCS::Inner()
{
    for (int i = 1; i < mx - 1; i++)
    {
        u_new[i] = u_prev[i] + 2 * sigma * (u_cur[i + 1] - 2 * u_cur[i] + u_cur[i - 1]);
    }
    current_step++;
}

void CTCS::Boundary()
{
    u_new[0] = left_boundary(current_step * dt);
    u_new[mx - 1] = right_boundary(current_step * dt);
}

void CTCS::Data()
{
    u_prev = u_cur;
    u_cur = u_new;
    if (current_step %5000== 0)
    {
        std::ofstream file(folder + "/CTCS_step_" + std::to_string(current_step) + ".txt");
        if (file.is_open())
        {
            for (int i = 0; i < mx; i++)
            {
                file << i * dx << " " << u_new[i] << "\n";
            }
            file.close();
        }
        else
        {
            std::cerr << "Error opening file for writing data.\n";
        }
    }
}

void CTCS::Forward()
{
    
    Inner();
    Boundary();
    Data();
    
}