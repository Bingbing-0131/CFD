#include "BTCS.h"

void BTCS::Initialize(int mx_, double gamma_, double sigma_, std::string folder_) {
    mx = mx_;
    dx = 1.0 / mx;
    gamma = gamma_;
    sigma = sigma_;
    dt = sigma * dx * dx / gamma;

    u_prev.resize(mx + 1);
    u_new.resize(mx + 1);
    
    for (int i = 0; i <= mx; i++) {
        u_prev(i) = Initial_condition(i * dx);
        u_new(i) = u_prev(i);
    }

    a.resize(mx + 1);
    b.resize(mx + 1);
    c.resize(mx + 1);
    d.resize(mx + 1);

    folder = folder_;
}

double BTCS::Initial_condition(double x) {
    if (x > 0.0 && x < 0.3) return 0.0;
    else if (x >= 0.3 && x <= 0.6) return 1.0;
    else if (x > 0.6 && x < 1.0) return 1 + 2.5 * (x - 0.6);
    else if (x == 0.0) return 0.0;
    else if (x == 1.0) return 2.0;
    
    std::cout << "Error: Out of Range" << std::endl;
    return 0.0;
}


double BTCS::left_boundary(double t) {
    return 0.0;
}

double BTCS::right_boundary(double t) {
    return 2.0+sin(10*t);
}


void BTCS::Build_Matrix(double t) {
    for (int i = 1; i < mx; i++) {
        a(i) = sigma;
        b(i) = -(1 + 2 * sigma);
        c(i) = sigma;
    }

    a(mx) = 0.0;
    b(0) = 1.0;
    b(mx) = 1.0;
    c(0) = 0.0;
    
    d(0) = left_boundary(t);
    d(mx) = right_boundary(t);

    for (int i = 1; i < mx; i++) {
        d(i) = -u_prev(i);
    }
}


void BTCS::Thomas(Eigen::VectorXd& a, Eigen::VectorXd& b, Eigen::VectorXd& c, Eigen::VectorXd& d, Eigen::VectorXd& x, int n) {
    Eigen::VectorXd u(n);
    Eigen::VectorXd l(n - 1);
    Eigen::VectorXd y(n);

    u(0) = b(0);
    y(0) = d(0);

    // Forward elimination
    for (int i = 1; i < n; i++) {
        if (u(i - 1) == 0) {
            throw std::runtime_error("Division by zero detected in Thomas algorithm.");
        }

        l(i - 1) = a(i) / u(i - 1);
        u(i) = b(i) - l(i - 1) * c(i - 1);
        y(i) = d(i) - l(i - 1) * y(i - 1);
    }

    x(n - 1) = y(n - 1) / u(n - 1);
    for (int i = n - 2; i >= 0; i--) {
        x(i) = (y(i) - c(i) * x(i + 1)) / u(i);
    }
}


void BTCS::Solve(int time_steps) {
    SaveResults(0);
    /*
    for (int t = 0; t < time_steps; t++) {
        Build_Matrix(t * dt);
        Thomas(a, b, c, d, u_new, mx + 1);
        
        u_prev = u_new; 
        if (t%400 == 0)
        {
            SaveResults(t);
        }
    }*/
}

// Save results to file
void BTCS::SaveResults(int step) {
    std::ofstream file(folder + "/BTCS_step_" + std::to_string(step) + ".txt");

    for (int i = 0; i <= mx; i++) {
        file << i * dx << " " << u_new(i) << std::endl;
    }
    
    file.close();
}
