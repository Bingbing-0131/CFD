#include <iostream>
#include <Eigen/Dense>
#include "FTCS.h"
#include "BTCS.h"
#include "CTCS.h"
int main()
{
    double gamma = 1.0;
    double sigma = 0.1;
    int mx = 200;
    int num_step;

    BTCS compute;
    std::string folder = "../FTCS/200_0.1";

    compute.Initialize(mx, gamma, sigma, folder);
    std::cout<<compute.dt_()<<std::endl;
    num_step = static_cast<int>(2.0 / compute.dt_());
    
    /*for (int i = 0; i < num_step; i++)
    {
        compute.Forward();
    }*/

   compute.Solve(num_step);

    return 0;
}