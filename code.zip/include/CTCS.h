#ifndef CTCS_H
#define CTCS_H


#include <Eigen/Dense>
#include <iostream>
#include <fstream>

class CTCS
{
public:
    void Initialize(int mx_, double gamma_, double sigma_, std::string folder_);
    void Inner();
    void Boundary();
    void Data();
    void Forward();
    double dt_() { return dt; }
    double Initial_condition(double x);
    double left_boundary(double t);
    double right_boundary(double t);

private:
    double dx = 0.0;
    int mx = 0;
    double dt = 0.0;
    double gamma = 0.0;
    double sigma = 0.0;
    int current_step = 0;
    std::string folder;
    Eigen::VectorXd u_prev;
    Eigen::VectorXd u_cur;
    Eigen::VectorXd u_new;
    
};

#endif