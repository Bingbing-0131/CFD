#ifndef BTCS_H
#define BTCS_H
#include <iostream>
#include <Eigen/Dense>
#include <fstream>

class BTCS {
private:
    int mx;  // Number of spatial grid points
    double dx, dt, gamma, sigma;
    std::string folder;
    
    Eigen::VectorXd u_prev, u_new;
    Eigen::VectorXd a, b, c, d;  // Tridiagonal matrix coefficients

public:
    // Function prototypes
    double Initial_condition(double x);
    double left_boundary(double t);
    double right_boundary(double t);
    
    void Initialize(int mx_, double gamma_, double sigma_, std::string folder_);
    void Build_Matrix(double t);
    void Thomas(Eigen::VectorXd& a, Eigen::VectorXd& b, Eigen::VectorXd& c, Eigen::VectorXd& d, Eigen::VectorXd& x, int n);
    void Solve(int time_steps);
    double dt_() { return dt; }
    void SaveResults(int step);
};

#endif